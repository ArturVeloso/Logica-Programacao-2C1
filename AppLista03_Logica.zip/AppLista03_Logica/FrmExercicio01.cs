﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Pegar os Valores na Tela
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Calcular a Soma
            soma = num1 + num3;

            //Mostrar Resultado
            MessageBox.Show("Soma = "+ soma);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //pegar valores na tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;
            
            //calcular a media
            media = (num1 + num2 + num3) / 3;

            //mostrar resultado
            MessageBox.Show("Media = " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //pegar valores na tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porc1, porc2, porc3;

            //calcular porcentagem
            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num1 / (num1 + num2 + num3) * 100;
            porc3 = num1 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem =" + porc1);
            MessageBox.Show("Porcentagem =" + porc2);
            MessageBox.Show("Porcentagem =" + porc3);
        }
    }
}
